/* =====================================================================
 *
 * Copyright (c) 2011 David Blevins.  All rights reserved.
 *
 * =====================================================================
 */
package org.acme;

public class NotAnnotated {

    private String green;

    private String red;

    public NotAnnotated() {}

    public NotAnnotated(String red) {}

    public void green() {}

    public void red() {}
}
